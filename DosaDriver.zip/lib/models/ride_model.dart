/*
import 'package:google_maps_flutter/google_maps_flutter.dart';

class RideUser {
  final String uid;
  final String name;
  final String? phone;
  final String? profileImage;

  RideUser({
    required this.uid,
    required this.name,
    this.phone,
    this.profileImage,
  });

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'name': name,
      'phone': phone,
      'profileImage': profileImage,
    };
  }

  factory RideUser.fromMap(Map<String, dynamic> map) {
    return RideUser(
      uid: map['uid'] ?? '',
      name: map['name'] ?? '',
      phone: map['phone'],
      profileImage: map['profileImage'],
    );
  }
}

class Ride {
  final String id;
  final LatLng pickup;
  final LatLng destination;
  final String status;

  Ride({
    required this.id,
    required this.pickup,
    required this.destination,
    required this.status,
  });
}

class RideModel {
  final String rideId;
  final RideUser client;
  final RideUser? captain;
  final Map<String, dynamic> pickup;
  final Map<String, dynamic> dropoff;
  final String status;
  final double distanceKm;
  final double estimatedFare;
  final dynamic createdAt;
  final dynamic updatedAt;

  RideModel({
    required this.rideId,
    required this.client,
    this.captain,
    required this.pickup,
    required this.dropoff,
    required this.status,
    required this.distanceKm,
    required this.estimatedFare,
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'rideId': rideId,
      'client': client.toMap(),
      'captain': captain?.toMap(),
      'pickup': pickup,
      'dropoff': dropoff,
      'status': status,
      'distanceKm': distanceKm,
      'estimatedFare': estimatedFare,
      'createdAt': createdAt,
      'updatedAt': updatedAt,
    };
  }

  factory RideModel.fromMap(Map<String, dynamic> map) {
    return RideModel(
      rideId: map['rideId'] ?? '',
      client: RideUser.fromMap(map['client'] ?? {}),
      captain: map['captain'] != null ? RideUser.fromMap(map['captain']) : null,
      pickup: map['pickup'] ?? {},
      dropoff: map['dropoff'] ?? {},
      status: map['status'] ?? '',
      distanceKm: (map['distanceKm'] ?? 0).toDouble(),
      estimatedFare: (map['estimatedFare'] ?? 0).toDouble(),
      createdAt: map['createdAt'],
      updatedAt: map['updatedAt'],
    );
  }
}
*/
